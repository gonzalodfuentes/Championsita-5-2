package com.proyecto.championsita;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.physics.box2d.Body;


public class Main extends ApplicationAdapter {
    private Menu menu;
    private boolean inMenu = true;

    private OrthographicCamera camera;
    private SpriteBatch batch;
    private World world;
    private Box2DDebugRenderer debugRenderer;
    private Ball ball;
    private Player playerA;
    private Player playerB;
    private Texture backgroundTexture;
    public static Texture player1Texture;
    public static Texture player2Texture;
    

    private int golesJugador1 = 0;
    private int golesJugador2 = 0;
    private BitmapFont font; // Para mostrar el contador de goles

    

    @Override
    public void create() {
        menu = new Menu();
        menu.create();
        batch = new SpriteBatch();
    }

    @Override
    public void render() {
        if (inMenu) {
            menu.render();
            if (menu.shouldStartMatch()) {
                inMenu = false;
                initializeMatch();
            }
        } else {
            renderMatch();
        }
        if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.Z)) {
            Gdx.app.exit();
        }
    }
    
 
    private void initializeMatch() {
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 16, 9);
        world = new World(new Vector2(0, -9.8f), true);
        debugRenderer = new Box2DDebugRenderer();
        batch = new SpriteBatch();

        backgroundTexture = new Texture("stadium.png");
        createFieldLines();
        createGoals(); // Añadir esta línea
        createBall();
        createPlayers();
    }

    private void renderMatch() {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        batch.draw(backgroundTexture, 0, 0, camera.viewportWidth, camera.viewportHeight);
        batch.end();

        world.step(1 / 60f, 6, 2);
        camera.update();

        playerA.update();
        playerB.update();

        playerA.handleInput(ball, true);
        playerB.handleInput(ball, false);

        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        ball.render(batch);
        playerA.render(batch, true);
        playerB.render(batch, false); // Indicar que es el jugador B
        batch.end();
        
        debugRenderer.render(world, camera.combined);
    }

    private void createBall() {
        float ballRadius = 0.30f;
        ball = new Ball(world, 8, 5, ballRadius, true);
    }
    
    private void createPlayers() {
        playerA = new Player(world, 2, 5, 0.5f, Main.player1Texture);
        playerB = new Player(world, 10, 5, 0.5f, Main.player2Texture);
    }
    
    
   
    

    private void createFieldLines() {
        createStaticBody(8, 0.5f, 16, 0.5f);
        createStaticBody(0, 4.5f, 0.5f, 9);
        createStaticBody(16, 4.5f, 0.5f, 9);
        createStaticBody(8, 9.5f, 16, 0.5f);
    }
    
    private void createGoals() {
        // Arco izquierdo
        createStaticBody(1, 4.5f, 2, 0.1f); // Ajusta la posición y tamaño según sea necesario
        
        // Arco derecho
        createStaticBody(15, 4.5f, 2, 0.1f); // Ajusta la posición y tamaño según sea necesario
    }
    
    private void createStaticBody(float x, float y, float width, float height) {
        var bodyDef = new com.badlogic.gdx.physics.box2d.BodyDef();
        bodyDef.position.set(x, y);
        bodyDef.type = com.badlogic.gdx.physics.box2d.BodyDef.BodyType.StaticBody;

        var body = world.createBody(bodyDef);

        var shape = new com.badlogic.gdx.physics.box2d.PolygonShape();
        shape.setAsBox(width / 2, height / 2);

        var fixtureDef = new com.badlogic.gdx.physics.box2d.FixtureDef();
        fixtureDef.shape = shape;
        body.createFixture(fixtureDef);
        shape.dispose();
    }

    @Override
    public void dispose() {
        menu.dispose();
        if (world != null) world.dispose();
        if (debugRenderer != null) debugRenderer.dispose();
        if (batch != null) batch.dispose();
        if (playerA != null) playerA.dispose();
        if (playerB != null) playerB.dispose();
        if (backgroundTexture != null) backgroundTexture.dispose();
    }
}
