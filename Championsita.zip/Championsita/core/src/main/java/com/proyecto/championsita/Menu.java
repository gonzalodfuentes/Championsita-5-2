package com.proyecto.championsita;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Menu {
    private SpriteBatch batch;
    private Texture backgroundTexture;
    private Texture player1CircleTexture;
    private Texture player2CircleTexture;
    private Texture[] characterTextures;
    private int player1Index = 0;
    private int player2Index = 0;
    private boolean startMatch = false;

    public void create() {
        batch = new SpriteBatch();
        backgroundTexture = new Texture("fondo.png");

        // C�rculos individuales para cada jugador
        player1CircleTexture = new Texture("cuadrado1.png");
        player2CircleTexture = new Texture("cuadrado2.png");

        characterTextures = new Texture[]{
                new Texture("cavani.png"),
                new Texture("rey.png"),
                new Texture("messi.png"),
                new Texture("martinez.png"),
                new Texture("mbappe.png"),
                new Texture("carbonero.png"),
                new Texture("borja.png"),
                new Texture("altamirano.png")
        };
    }

    public void render() {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.begin();
     // Dibujar fondo del men�
     batch.draw(backgroundTexture, 0, 0, 1280, 720);

     // Dibujar c�rculos para los jugadores
     batch.draw(player1CircleTexture, 200, 470, 150, 150); // C�rculo jugador 1
     batch.draw(player2CircleTexture, 900, 470, 150, 150); // C�rculo jugador 2

     // Dibujar cuadros de selecci�n con las im�genes de los personajes
     batch.draw(characterTextures[player1Index], 200, 300, 150, 150);

     // Girar el segundo jugador 180 grados
     batch.draw(
         characterTextures[player2Index], 
         1050, 300,    // Coordenadas de la esquina inferior izquierda
         -150, 150     // Escala negativa en el ancho para voltear la textura horizontalmente
     );

     batch.end();

        // Mover selecci�n
        if (Gdx.input.isKeyJustPressed(Input.Keys.A)) {
            player1Index = (player1Index > 0) ? player1Index - 1 : characterTextures.length - 1;
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.D)) {
            player1Index = (player1Index + 1) % characterTextures.length;
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.LEFT)) {
            player2Index = (player2Index > 0) ? player2Index - 1 : characterTextures.length - 1;
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.RIGHT)) {
            player2Index = (player2Index + 1) % characterTextures.length;
        }

        // Confirmar selecci�n
        if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER)) {
            Main.player1Texture = characterTextures[player1Index];
            Main.player2Texture = characterTextures[player2Index];
            startMatch = true;
        }
    }

    public boolean shouldStartMatch() {
        return startMatch;
    }

    public void dispose() {
        batch.dispose();
        backgroundTexture.dispose();
        player1CircleTexture.dispose();
        player2CircleTexture.dispose();
        for (Texture texture : characterTextures) {
            texture.dispose();
        }
    }
}
